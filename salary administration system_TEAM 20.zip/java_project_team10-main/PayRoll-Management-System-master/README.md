# PayRoll-Management-System

INTRODUCTION

Payroll system is the heart of any Human Resource System of an organization. The solution has to take care of the calculation of salary as per rules
of the company and various deductions to be done from the salary. It has to generate pay-slip, mark attendance. Managing thousands of odd papers, 
pay slips, payroll reports and salary details and so on can be tiresome. If we have a payroll processing system which will generate our pay slips 
and payroll reports within seconds would be very helpful and would save our time.

OBJECTIVE OF THE PAYROLL MANAGEMNET SYSTEM

The main objective of the payroll management system is to provide an easy way out to automate all the functionalities.
It manages the details of the employees, calculates their salary, marks attendance. 
It will manage all the details of the employees and payments. 
The project is totally built at administrative end and thus only the administrator is guaranteed the access. 
The purpose of this project is to reduce the manual work.



Features of payroll management system is as follows :-

1>The data is only accessible to the administrator.																																																															
2>To improve the efficiency.
3>Stores all the details of the employees.
4>The administrator can easily change or update an employees data.
5>Manages the information of salary.
6>Automatically calculates the salary based on the number of working days of the employee.
7>List employees attendance.
8>Every employee has a special employee ID.
9>With employee ID you can fetch the employees data as well a salary.
10>Prints salary slip.
11>Quickly finds out information of an employee details.
12>Provides easy and faster access information.
13>Administrator needs to only have basic information about the database.
